/**
 * Created on 16.07.2012
 *
 * © 2012 Daniel Thommes
 */
package org.robospring.inject;

public enum AndroidResourceType {
	id, anim, color, drawable, layout, menu, string, array, plurals, style, bool, integer, dimen, values, xml
}